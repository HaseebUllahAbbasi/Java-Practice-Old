/**
 * This is the Module of the template
 */
module project_module
{
    requires javafx.fxml;
    requires javafx.controls;
    opens img_drag;
}